package com.frameweb.java;


import java.io.Serializable;
import java.util.List;

public interface AutorDAO extends Serializable {
	
}