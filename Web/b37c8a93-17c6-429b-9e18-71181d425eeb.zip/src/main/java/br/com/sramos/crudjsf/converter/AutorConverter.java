package com.frameweb.java;


public class AutorConverter  {



	public AutorConverter(){
		
	}


	
}