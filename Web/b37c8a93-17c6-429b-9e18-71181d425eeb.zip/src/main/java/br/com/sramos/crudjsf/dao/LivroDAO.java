package com.frameweb.java;


import java.io.Serializable;
import java.util.List;

public interface LivroDAO extends Serializable {
	
}