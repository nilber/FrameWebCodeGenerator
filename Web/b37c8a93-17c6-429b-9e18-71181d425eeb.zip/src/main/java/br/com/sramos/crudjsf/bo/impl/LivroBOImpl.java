package com.frameweb.java;


public class LivroBOImpl  {



	public LivroBOImpl(){
		
	}


	public void salvar(Livro livroETERS){
		return null;
	}
	public void deletar(Livro livroETERS){
		return null;
	}
	public void buscarTodos(ETERS){
		return null;
	}
	public //@compose.1/br.com.sramos.crudjsf.model/Livro buscarPorId(long idETERS){
		return null;
	}
	
}