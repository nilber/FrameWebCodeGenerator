package com.frameweb.java;

import java.util.List;

public class LivroJPA extends AbstractJPA implements LivroDAO{

	


private long serialVersionUID;

public long getSerialVersionUID(){
	return serialVersionUID;
}

public void setSerialVersionUID(long _serialVersionUID){
	serialVersionUID = _serialVersionUID;
}



	public void salvar(Livro livro){
		
	}


	public void deletar(Livro livro){
		
	}


	public List buscarTodos(){
		
	}


	public void buscarPorId(long id){
		return null;
	}



	public LivroJPA()
	{
		
	}
	
	

}

