package com.frameweb.java;

import java.util.List;

public abstract class AbstractJPA  {

	


 EntityManager EntityManager;

public EntityManager getEntityManager(){
	return EntityManager;
}

public void setEntityManager(EntityManager _EntityManager){
	EntityManager = _EntityManager;
}




	public AbstractJPA()
	{
		
	}
	
	

}

