package com.frameweb.java;

import java.util.List;

public class AutorJPA extends AbstractJPA implements AutorDAO{

	


private long serialVersionUID;

public long getSerialVersionUID(){
	return serialVersionUID;
}

public void setSerialVersionUID(long _serialVersionUID){
	serialVersionUID = _serialVersionUID;
}



	public void salvar(Autor autor){
		
	}


	public void excluir(Autor autor){
		
	}


	public List buscarTodos(){
		
	}


	public void buscarPorId(long id){
		return null;
	}


	public List buscarPorIdLivro(long idLivro){
		
	}



	public AutorJPA()
	{
		
	}
	
	

}

