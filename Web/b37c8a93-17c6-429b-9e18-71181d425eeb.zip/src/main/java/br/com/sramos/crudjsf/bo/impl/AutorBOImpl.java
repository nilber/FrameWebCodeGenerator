package com.frameweb.java;


public class AutorBOImpl  {



	public AutorBOImpl(){
		
	}


	public void salvar(Autor autorETERS){
		return null;
	}
	public void excluir(Autor autorETERS){
		return null;
	}
	public void buscarTodos(ETERS){
		return null;
	}
	public //@compose.1/br.com.sramos.crudjsf.model/Autor buscarPorId(long idETERS){
		return null;
	}
	public void buscarPorIdLivro(long idLivroETERS){
		return null;
	}
	
}