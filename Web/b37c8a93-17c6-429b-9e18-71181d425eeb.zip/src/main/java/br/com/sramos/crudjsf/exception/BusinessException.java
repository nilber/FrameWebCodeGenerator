package com.frameweb.java;


public class BusinessException  {



private long serialVersionUID;

public long getSerialVersionUID(){
	return serialVersionUID;
}

public void setSerialVersionUID(long _serialVersionUID){
	serialVersionUID = _serialVersionUID;
}

	public BusinessException(){
		
	}


	
}