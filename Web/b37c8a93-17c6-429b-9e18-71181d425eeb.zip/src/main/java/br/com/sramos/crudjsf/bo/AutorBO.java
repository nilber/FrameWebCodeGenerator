package com.frameweb.java;


interface AutorBO {


	
}