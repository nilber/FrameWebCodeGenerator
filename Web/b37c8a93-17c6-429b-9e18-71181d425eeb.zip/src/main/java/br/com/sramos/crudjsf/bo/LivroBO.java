package com.frameweb.java;


interface LivroBO {


	
}